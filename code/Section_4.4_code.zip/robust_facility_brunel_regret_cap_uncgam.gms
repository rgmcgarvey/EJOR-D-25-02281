*****MINIMAX REGRET FORMULATION
sets
i_in full demands /i0001*i1000/
j_in full facilities /j001*j100/
$include batch_subsets.inc
$include batch_data.inc
psi scenarios /psi001*psi999/
psi_ccg(psi) set of active scenarios;
psi_ccg('psi001')=yes;
singleton set psipsi(psi) used to add scenarios to active set;
*****CALCULATE MINIMUM COST ASSUMING NO DEMAND VARIABILITY
free variables regret objective for initial regret calculations;
binary variable y_regret(j) prepare and utilize facility j in initial regret calculations;
positive variable v_regret(j) prepare and utilize facility j in initial regret calculations;
positive variable w_regret(i,j) amount shipped from i to j in initial regret calculations;
positive variable x_regret(i) unmet demand at customer i in initial regret calculations;
parameters
alpha(j) preparation cost for facility site j
gamma(j) utilization cost for facility j
zeta(i,j) transport cost between i and j
eta(i) demand shortfall cost at customer i
sigmabar(i) nominal demand at customer i
sigmahatplus(i) potential demand increase at customer i
sigmahatminus(i) potential demand decrease at customer i
zplusstar_regret(i) fixed values defining demand increases at customer i in initial regret calculations
zminusstar_regret(i) fixed values defining demand decreases at customer i in initial regret calculations
GAMMABAR(J) nominal utilization cost for facility j
GAMMAHATPLUS(J) potential utilization cost increase for facility j
GAMMAHATMINUS(J) potential utilization cost decrease for facility j
GPLUSSTAR_REGRET(J) fixed values defining utilization cost increases as facility j in initial regret calculations
GMINUSSTAR_REGRET(J) fixed values defining utilization cost decreases as facility j in initial regret calculations
theta(j) service capacity at facility j;
equations
objec_regret initial regret objective
demand_regret(i) initial regret demand constraint
capacity_regret(j) initial regret capacity constraint
open_regret(j) initial regret open constraint;
objec_regret..       regret =E= sum(j,alpha(j)*y_regret(j)+(GAMMABAR(J)+GAMMAHATPLUS(J)*GPLUSSTAR_REGRET(J)-GAMMAHATMINUS(J)*GMINUSSTAR_REGRET(J))*v_regret(j))+sum((i,j),zeta(i,j)*w_regret(i,j))+sum(i,eta(i)*x_regret(i));
demand_regret(i)..   sum(j,w_regret(i,j))+x_regret(i) =E= sigmabar(i)+sigmahatplus(i)*zplusstar_regret(i)-sigmahatminus(i)*zminusstar_regret(i);
capacity_regret(j).. sum(i,w_regret(i,j)) =L= theta(j)*v_regret(j);
open_regret(j)..     v_regret(j) =L= y_regret(j);
model regret_calc /objec_regret,demand_regret,capacity_regret,open_regret/;
parameter deleteme /1/;
*****CCG MAIN PROBLEM
free variables mu main problem objective function value;
binary variables y(j) prepare facility site j;
positive variables v_m(j,psi) utilize facility j in scenario psi;
positive variables w_m(i,j,psi) amount shipped from i to j in scenario psi;
positive variables x_m(i,psi) unmet demand at customer i in scenario psi;
parameters
regret_scen(psi) regret objective for scenario psi
GPLUSSTAR(J,PSI) fixed values defining utilization cost increases at facility j in scenario psi
GMINUSSTAR(J,PSI) fixed values defining utilization cost increases at facility j in scenario psi
zplusstar(i,psi) fixed values defining demand increases at customer i in scenario psi
zminusstar(i,psi) fixed values defining demand decreases at customer i in scenario psi;
equations
objec_mp(psi) objective function cannot be less than cost in scenario psi
demand_mp(i,psi) allocate demand for customer i across facilities and shortfall for scenario psi
capacity_mp(j,psi) cannot exceed service capacity at facility j in scenario psi
open_mp(j,psi) can only utilize site j in scenario psi if site was prepared;
objec_mp(psi_ccg)..      mu =G= sum(j,alpha(j)*y(j)+(GAMMABAR(J)+GAMMAHATPLUS(J)*GPLUSSTAR(J,PSI_CCG)-GAMMAHATMINUS(J)*GMINUSSTAR(J,PSI_CCG))*v_m(j,psi_ccg))+sum((i,j),zeta(i,j)*w_m(i,j,psi_ccg))+sum(i,eta(i)*x_m(i,psi_ccg))-deleteme*regret_scen(psi_ccg);
demand_mp(i,psi_ccg)..   sum(j,w_m(i,j,psi_ccg))+x_m(i,psi_ccg) =G= sigmabar(i)+sigmahatplus(i)*zplusstar(i,psi_ccg)-sigmahatminus(i)*zminusstar(i,psi_ccg);
capacity_mp(j,psi_ccg).. sum(i,w_m(i,j,psi_ccg)) =L= theta(j)*v_m(j,psi_ccg);
open_mp(j,psi_ccg)..     v_m(j,psi_ccg) =L= y(j);
EQUATION REDUND(I,J,PSI) REDUNDANT;
REDUND(I,J,PSI_CCG).. W_M(I,J,PSI_CCG)/(sigmabar(i)+sigmahatplus(i)*zplusstar(i,psi_ccg)-sigmahatminus(i)*zminusstar(i,psi_ccg)) =L= Y(J);
model robust_mp /objec_mp,demand_mp,capacity_mp,open_mp,redund/;
*****CCG SUB PROBLEM
free variables tau sub-master problem objective function value;
free variables cost used to decompose objective;
free variables regret_lambda variable;
positive variables a(i) dual variable for primal demand constraint;
positive variables b(j) dual variable for primal capacity constraint;
positive variables c(j) dual variable for primal open constraint;
positive variable r(i) used to linearize dual;
positive variable rn(i) used to linearize dual;
POSITIVE VARIABLES HPLUS(J) used to linearize dual;
POSITIVE VARIABLES HMINUS(J) used to linearize dual;
binary variables zplus(i) increase demand at customer i;
binary variables zminus(i) decrease demand at customer i;
BINARY VARIABLES GPLUS(J) increase utilization cost at facility j;
BINARY VARIABLES GMINUS(J) decrease utilization cost at facility j;
binary variables y_submain(j) regret variable;
positive variables v_submain(j) regret variable;
positive variables w_submain(i,j) regret variable;
positive variables x_submain(i) regret variable;
parameters
ystar(j) fixed values defining preparation of facility site j
RHO_G uncertainty budget for cost utilization
rho uncertainty budget;
equations
objec_submain regret objective
objec_submain_soln cost of best solution
objec_submain_regret corresponding regret cost
dual_v(j) dual constraint for primary variable v
dual_w(i,j) dual constraint for primary variable w
dual_x(i) dual constraint for primary variable x
sum_z number of demand deviations cannot exceed uncertainty budget
either_z(i) at most one demand deviation for customer i
demand_submain(i) allocate demand for customer i across facilities and shortfall for corresponding regret solution
capacity_submain(j) cannot exceed service capacity at facility j for corresponding regret solution
open_submain(j) can only utilize site j if site was prepared
rcon1(i) dual linearization constraint
rcon2(i) dual linearization constraint
rcon3(i) dual linearization constraint
rcon1n(i) dual linearization constraint
rcon2n(i) dual linearization constraint
rcon3n(i) dual linearization constraint
SUM_G number of utilization cost deviations cannot exceed uncertainty budget
EITHER_G(J) at most one utilization cost deviation for customer j
HCON1(J) dual linearization constraint
HCON2(J) dual linearization constraint
HCON3(J) dual linearization constraint
HCON1N(J) dual linearization constraint
HCON2N(J) dual linearization constraint
HCON3N(J) dual linearization constraint;
objec_submain..          tau =E= cost-deleteme*regret_lambda;
objec_submain_soln..     cost =E= sum(j,alpha(j)*ystar(j))+sum(i,a(i)*sigmabar(i)+sigmahatplus(i)*r(i)-sigmahatminus(i)*rn(i))-sum(j,c(j)*ystar(j));
objec_submain_regret..   regret_lambda =E= sum(j,(alpha(j)*y_submain(j))+GAMMABAR(J)*v_submain(j)+GAMMAHATPLUS(J)*HPLUS(J)-GAMMAHATMINUS(J)*HMINUS(J))+sum((i,j),zeta(i,j)*w_submain(i,j))+sum(i,eta(i)*x_submain(i));
dual_v(j)..              theta(j)*b(j)-c(j) =L= (GAMMABAR(J)+GAMMAHATPLUS(J)*GPLUS(J)-GAMMAHATMINUS(J)*GMINUS(J));
dual_w(i,j)..            a(i)-b(j) =L= zeta(i,j);
dual_x(i)..              a(i) =L= eta(i);
sum_z..                  sum(i,zplus(i)+zminus(i)) =L= rho;
either_z(i)..            zplus(i)+zminus(i) =L= 1;
demand_submain(i)..      sum(j,w_submain(i,j))+x_submain(i) =E= sigmabar(i)+sigmahatplus(i)*zplus(i)-sigmahatminus(i)*zminus(i);
capacity_submain(j)..    sum(i,w_submain(i,j)) =L= theta(j)*v_submain(j);
open_submain(j)..        v_submain(j) =L= y_submain(j);
rcon1(i)..    r(i) =L= a(i);
rcon2(i)..    r(i) =L= eta(i)*zplus(i);
rcon3(i)..    r(i) =G= a(i)-eta(i)*(1-zplus(i));
rcon1n(i)..   rn(i) =L= a(i);
rcon2n(i)..   rn(i) =L= eta(i)*zminus(i);
rcon3n(i)..   rn(i) =G= a(i)-eta(i)*(1-zminus(i));
SUM_G..                  SUM(J,GPLUS(J)+GMINUS(J)) =L= RHO_G;
EITHER_G(J)..            GPLUS(J)+GMINUS(J) =L= 1;
HCON1(J)..   HPLUS(J) =L= V_SUBMAIN(J);
HCON2(J)..   HPLUS(J) =L= GPLUS(J);
HCON3(J)..   HPLUS(J) =G= V_SUBMAIN(J)+GPLUS(J)-1;
HCON1N(J)..  HMINUS(J) =L= V_SUBMAIN(J);
HCON2N(J)..  HMINUS(J) =L= GMINUS(J);
HCON3N(J)..  HMINUS(J) =G= V_SUBMAIN(J)+GMINUS(J)-1;
model robust_sub_regret /objec_submain,objec_submain_soln,objec_submain_regret,dual_v,dual_w,dual_x,sum_z,either_z,demand_submain,capacity_submain,open_submain,rcon1,rcon2,rcon3,rcon1n,rcon2n,rcon3n,SUM_G,EITHER_G,HCON1,HCON2,HCON3,HCON1N,HCON2N,HCON3N/;
*****CCG ALGORITHM
parameters
eps_m termination criteria for master problem /0.000001/
kappa_m count for number of active scenarios in master problem /1/
kappa_m_max iteration limit on master problem /200/
mu_lo lower bound from master problem /-inf/
mu_hi upper bound from subproblem /9e9/
zplusstar_sp(i) fixed values defining demand increases at customer i
zminusstar_sp(i) fixed values defining demand decreases at customer i
zplus_tilde(i) record best subproblem solution
zminus_tilde(i) record best subproblem solution
GPLUSSTAR_SP(J) fixed values defining utilization cost increases at facility j
GMINUSSTAR_SP(J) fixed values defining utilization cost decreases at facility j
GPLUS_TILDE(J) record best subproblem solution
GMINUS_TILDE(J) record best subproblem solution
y_tilde(j) record best solution;
option threads=0;
option optcr=0;
option reslim=900;
robust_mp.optfile=1;
robust_sub_regret.optfile=2;
file fcpx / "cplex.op2" /;
$onecho  > cplex.opt
mipemphasis=2
BendersStrategy 3
names no
tilim 600
$offecho
set scencnt track outputs /sc001*sc1999/;
parameter scnt track outputs /1/;
parameter y_out_all(j,scencnt) track outputs;
parameter zplus_out_all(i,scencnt) track outputs;
parameter zminus_out_all(i,scencnt) track outputs;
parameter gplus_out_all(j,scencnt) track outputs;
parameter gminus_out_all(j,scencnt) track outputs;
parameter tmax_ccg time limit for overall ccg procedure /6000/;
parameter flag track deleteme value;
parameter di(i) distance between customer i and nearest opened facility
parameter wcd worst cast distance;
parameter wwcd weight of worst case distance;
parameter bcd best case distance;
parameter wbcd weight of best case distance;
parameter avdi average distance;
parameter origval /20/;
parameter rawval;
parameter newflag /0/;
$include iterate_def.inc
rawval=origval;
GAMMABAR(J)=GAMMA(J);
GAMMAHATPLUS(J)=0.5*GAMMABAR(J);
GAMMAHATMINUS(J)=GAMMAHATPLUS(J);
******CCG algorithm START
while (((mu_hi-mu_lo)/(abs(mu_lo)+1e-9)>eps_m)and(kappa_m<kappa_m_max)and(mu_hi>eps_m)and(robust_mp_time_total+robust_sub_time_total<tmax_ccg),
 if(kappa_m=1, 
  zplusstar_regret(i)=0;
  zminusstar_regret(i)=0;
  GPLUSSTAR_REGRET(J)=0;
  GMINUSSTAR_REGRET(J)=0;
  solve regret_calc using mip minimizing regret;
  robust_mp_time_total = robust_mp_time_total + regret_calc.resGen + regret_calc.resUsd;
  regret_scen('psi001')=regret.l;
  zplusstar(i,'psi001')=0;
  zminusstar(i,'psi001')=0;
  GPLUSSTAR(J,'PSI001')=0;
  GMINUSSTAR(J,'PSI001')=0;
);
 solve robust_mp using mip minimizing mu;
 robust_mp_time_total = robust_mp_time_total + robust_mp.resGen + robust_mp.resUsd;
 ystar(j)=0;
 if ((robust_mp.modelstat=1)or(robust_mp.modelstat=8),
  ystar(j)=round(y.l(j));
 else
  robust_mp.objest=-inf;
 );
 mu_lo=max(mu_lo,robust_mp.objest);
 put /;
 put "mu_lo";
 put mu_lo;
 put robust_mp.modelstat;
 put /;
 mu.lo=mu_lo;
* tau.lo=mu_lo;
******CCG to solve subproblem_START
if(((mu_hi-mu_lo)/(abs(mu_lo)+1e-9)>eps_m),
 put fcpx "mipemphasis 3" /
 "mipstopexpr objval >=" mu_hi /
 "names no" /
 "tilim" rawval /;
 putclose fcpx;
 solve robust_sub_regret using mip maximizing tau;
 robust_sub_time_total = robust_sub_time_total + robust_sub_regret.resGen + robust_sub_regret.resUsd;
********
while(newflag=0,
if((robust_sub_regret.modelstat=14)or((robust_sub_regret.modelstat=8)and(tau.l<=mu_lo+1e-3)),
  rawval=max(0,min(5*rawval,tmax_ccg-(robust_mp_time_total+robust_sub_time_total)));
  put fcpx "mipemphasis 3" /
  "mipstopexpr objval >=" mu_hi /
  "names no" /
  "tilim" rawval /;
  putclose fcpx;
  solve robust_sub_regret using mip maximizing tau;
  robust_sub_time_total = robust_sub_time_total + robust_sub_regret.resGen + robust_sub_regret.resUsd;
  if(tmax_ccg<(robust_mp_time_total+robust_sub_time_total),
   rawval=origval;
   newflag=1;
   )
else
 rawval=origval;
 newflag=1;
);
);
newflag=0;
********
 zplusstar_sp(i)=0;
 zminusstar_sp(i)=0;
 GPLUSSTAR_SP(J)=0;
 GMINUSSTAR_SP(J)=0;
 if ((robust_sub_regret.modelstat=1)or(robust_sub_regret.modelstat=8),
  zplusstar_sp(i)=round(zplus.l(i));
  zminusstar_sp(i)=round(zminus.l(i));
  GPLUSSTAR_SP(J)=ROUND(GPLUS.L(J));
  GMINUSSTAR_SP(J)=ROUND(GMINUS.L(J));
  regret_scen(psi)$(ord(psi)=kappa_m+1)=regret_lambda.l;
 else
  robust_sub_regret.objest=inf;
  regret_scen(psi)$(ord(psi)=kappa_m+1)=regret_scen('psi001');
 );
******CCG to solve subproblem_STOP
 mu_hi=min(mu_hi,robust_sub_regret.objest);
 put robust_facility_results;
 put "mu_hi";
 put mu_hi;
 put robust_sub_regret.modelstat;
 put /;
 if(mu_hi=robust_sub_regret.objest,
  y_tilde(j)=ystar(j);
  zplus_tilde(i)=zplusstar_sp(i);
  zminus_tilde(i)=zminusstar_sp(i);
  GPLUS_TILDE(J)=GPLUSSTAR_SP(J);
  GMINUS_TILDE(J)=GMINUSSTAR_SP(J);
 );
 kappa_m=kappa_m+1;
 loop(i,
  zplusstar(i,psi)$(ord(psi)=kappa_m)=zplusstar_sp(i);
  zminusstar(i,psi)$(ord(psi)=kappa_m)=zminusstar_sp(i);
  GPLUSSTAR(J,PSI)$(ORD(PSI)=KAPPA_M)=GPLUSSTAR_SP(J);
  GMINUSSTAR(J,PSI)$(ORD(PSI)=KAPPA_M)=GMINUSSTAR_SP(J);
 );
 psipsi(psi)$(ord(psi)=kappa_m)=yes;
 psi_ccg(psi)=psi_ccg(psi)+psipsi(psi);
);
);
******CCG algorithm STOP
put fcpx "mipemphasis 2" /
"names no" /
"tilim" rawval /;
putclose fcpx;
put robust_facility_results;
y_out_all(j,scencnt)$(ord(scencnt)=scnt)=y_tilde(j);
zplus_out_all(i,scencnt)$(ord(scencnt)=scnt)=zplus_tilde(i);
zminus_out_all(i,scencnt)$(ord(scencnt)=scnt)=zminus_tilde(i);
gplus_out_all(j,scencnt)$(ord(scencnt)=scnt)=gplus_tilde(j);
gminus_out_all(j,scencnt)$(ord(scencnt)=scnt)=gminus_tilde(j);
scnt=scnt+1;
$include print_outputs.inc